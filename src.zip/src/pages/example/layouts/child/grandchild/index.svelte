<div style="text-align: center">
  <h4>I'm src/pages/example/nesting/child/grandchild/index.svelte</h4>
</div>
