<div style="text-align: center">
  <h1>I'm src/pages/example/nesting/child/index.svelte</h1>
</div>
