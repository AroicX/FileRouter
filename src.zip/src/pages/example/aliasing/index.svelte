
<p>Pages can redirect to other pages while not changing the current URL.</p>
<p>By using _fallback.svelte we can reference whole libraries and modules instead of having to duplicate them.</p>