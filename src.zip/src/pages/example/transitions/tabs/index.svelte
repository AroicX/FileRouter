<script>
  import { redirect } from '@sveltech/routify'
  $redirect('../home')
</script>