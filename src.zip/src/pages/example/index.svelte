<script>
  import base64Logo from "./_components/assets/logo.js";
</script>

<!-- routify:option name="example-app" -->

<div style="width: 100%; text-align: center; margin-top: 4rem;">
  <img src="data:image/png;base64, {base64Logo}" alt="logo" style="padding-bottom: 128px" />
  <div>
    <b>Guide:</b>
    <br />
    <a href="https://routify.dev">https://routify.dev</a>
  </div>

  <br />
  <div>
    <b>This template:</b>
    <br />
    <a href="https://github.com/sveltech/routify-starter">
      https://github.com/sveltech/routify-starter
    </a>
  </div>

</div>
