<h1>Routify Starter</h1>

To see an example app, go to 
<a href="/example">/example</a>

<p>To delete the example app, simply delete the ./src/pages/example folder.</p>