<!-- We don't want to inherit the parent layout on the login page, so we use a reset to clear the scope. -->
<slot></slot>