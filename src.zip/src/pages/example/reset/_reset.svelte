<slot>
  <!-- optional fallback -->
</slot>