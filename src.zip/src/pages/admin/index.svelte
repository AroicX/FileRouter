<script>
    import { onMount } from "svelte";


    onMount(() => {
       alert('...working')
    })


</script>

<div>admin index</div>
