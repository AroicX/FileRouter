<script>
    import RoutifyIntro from './example/_components/RoutifyIntro.svelte'
</script>

<RoutifyIntro />