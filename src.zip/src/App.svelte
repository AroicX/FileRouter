<script>
  import { Router } from "svelte-filerouter";
</script>

<Router />
